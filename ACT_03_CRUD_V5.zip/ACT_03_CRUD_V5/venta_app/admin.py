from django.contrib import admin
from .models import Ventas
admin.site.register(Ventas)